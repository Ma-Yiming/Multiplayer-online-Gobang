import socket
import pygame
import threading
from pygame.locals import *
from Game import *
import time
import sys

class Client():
    def __init__(self,ip_port,mapclass,screen):
        self.num = ''
        self.iswaiting = 0
        self.screen=screen
        self.map1=mapclass
        self.sk = socket.socket()
        self.sk.connect(ip_port)
        self.sk.settimeout(5)
        self.White_win=0
        self.Black_win=0
        self.winner=0
        self.end = 0
        self.turn = 1
        self.thread()
        self.round()
    def wait(self):
        while True:
            try:
                #一直得带接受信息
                data = self.sk.recv(1024).decode()
                print(data)
                if self.num == '':
                    self.num=((data.split('|')[1])[0])
                    break
                x=int(data.split(',')[0])
                y=int(data.split(',')[1])
                self.map1.click(x,y)
                print(self.map1.steps)
                self.map1.drawChess(self.screen)
                if self.turn == 1:
                    self.turn = 2
                else:
                    self.turn = 1
            except:
                #不会进来
                pygame.display.flip()
                continue
    def thread(self):
        t = threading.Thread(target=self.wait)
        t.start()
    def round(self):
        self.wait()
        if self.num == '1':
            while True:
                running = True
                while running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                        if event.type == pygame.MOUSEBUTTONDOWN and \
                           self.turn == 1:
                            x,y=self.clickwhere()
                            running = False
                send_data = str(x)+','+str(y)
                self.sk.sendall(bytes(self.num+':'+send_data,encoding='utf-8'))
                self.turn = 2
        elif self.num == '2':
            while True:
                running = True
                while running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                        if event.type == pygame.MOUSEBUTTONDOWN and\
                           self.turn == 2:
                            x,y=self.clickwhere()
                            running = False
                send_data = str(x)+','+str(y)
                self.sk.sendall(bytes(self.num+':'+send_data,encoding='utf-8'))
                self.turn = 1
    #获取点击位置并绘图判断是否结束
    def clickwhere(self):
        map_x,map_y=pygame.mouse.get_pos()
        x,y=self.map1.MapPos(map_x,map_y)
        #print(map_x,"-----",map_y,"-----",x,"-----",y)
        #下边的先后顺序不能反，不然会有数组越界报错
        if self.map1.IsinMap(x,y) and self.map1.Isempty(x,y):
            self.map1.click(x,y)
            if not self.IsEnd(x,y):
                self.map1.drawChess(self.screen)
                return (x,y)
        if self.White_win==5 or self.Black_win==5:
            if self.White_win == 5:
                self.winner = 0
            else:
                self.winner = 1
            #print("map end")
            self.map1.drawChess(self.screen)
            return (x,y)
            self.White_win=0
            self.Black_win=0
                
    #四种方向的结束条件
    def IsEnd(self,x,y):
        for i in range(-4,5):
            if x+i > 0 and x+i < 16:
                #print(x+i,self.map1.map[y-1][x+i-1])
                if self.map1.map[y-1][x+i-1]==1:
                    self.Black_win=0
                    self.White_win+=1
                elif self.map1.map[y-1][x+i-1]==2:
                    self.White_win=0
                    self.Black_win+=1
                else:
                    self.White_win=0
                    self.Black_win=0
            if self.White_win==5:
                return 1
            if self.Black_win==5:
                return 2
        self.White_win=0
        self.Black_win=0
        for j in range(-4,5):
            if y+j > 0 and y+j < 16:
                if self.map1.map[y+j-1][x-1]==1:
                    self.Black_win=0
                    self.White_win+=1
                elif self.map1.map[y+j-1][x-1]==2:
                    self.White_win=0
                    self.Black_win+=1
                else:
                    self.White_win=0
                    self.Black_win=0
            if self.White_win==5:
                return 1
            if self.Black_win==5:
                return 2
        #print(self.White_win,self.Black_win)
        self.White_win=0
        self.Black_win=0
        for m in range(-4,5):
            if y+m > 0 and y+m < 16 and x+m > 0 and x+m < 16:
                if self.map1.map[y+m-1][x+m-1]==1:
                    self.Black_win=0
                    self.White_win+=1
                elif self.map1.map[y+m-1][x+m-1]==2:
                    self.Black_win+=1
                    self.White_win=0
                else:
                    self.White_win=0
                    self.Black_win=0
            if self.White_win==5:
                return 1
            if self.Black_win==5:
                return 2
        #print(self.White_win,self.Black_win)
        self.White_win=0
        self.Black_win=0
        for n in range(-4,5):
            if y-n > 0 and y-n < 16 and x+n > 0 and x+n < 16:
                if self.map1.map[y-n-1][x+n-1]==1:
                    self.Black_win=0
                    self.White_win+=1
                elif self.map1.map[y-n-1][x+n-1]==2:
                    self.Black_win+=1
                    self.White_win=0
                else:
                    self.White_win=0
                    self.Black_win=0
           # print(self.White_win,self.Black_win)
            if self.White_win==5:
                return 1
            if self.Black_win==5:
                return 2
        #print(self.White_win,self.Black_win)
        self.White_win=0
        self.Black_win=0
        return 0
    def End(self):
        return self.end
