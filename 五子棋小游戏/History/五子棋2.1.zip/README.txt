须知：
点击Main.py即可运行游戏。

点击开始游戏需输入两位对战者的名字，因为编码原因暂时不能使用中文

本软件用到的库如下：
pygame
sys
time
os
pandas
tkinter